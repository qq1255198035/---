import SMenu from './menu'
export default SMenu
